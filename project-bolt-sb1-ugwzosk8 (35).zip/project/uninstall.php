<?php
// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options
delete_option('dic_options');

// Delete database tables
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}dic_tables");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}dic_entries");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}dic_temp_uploads");

// Delete uploaded files
$upload_dir = wp_upload_dir();
$dic_entries_dir = $upload_dir['basedir'] . '/dic-entries';
$dic_temp_dir = $upload_dir['basedir'] . '/dic-temp';

// Function to recursively delete a directory
function dic_recursive_rmdir($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object)) {
                    dic_recursive_rmdir($dir . "/" . $object);
                } else {
                    unlink($dir . "/" . $object);
                }
            }
        }
        rmdir($dir);
    }
}

// Delete the directories
if (is_dir($dic_entries_dir)) {
    dic_recursive_rmdir($dic_entries_dir);
}

if (is_dir($dic_temp_dir)) {
    dic_recursive_rmdir($dic_temp_dir);
}