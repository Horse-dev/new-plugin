<?php
/**
 * Plugin Name: AI Document Checker
 * Description: A plugin that allows users to upload files and compares them against admin-defined records using AI.
 * Version: 1.9.0
 * Author: Horse Dev Team
 * Text Domain: document-icon-checker
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('DIC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DIC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DIC_PLUGIN_VERSION', '1.9.0');

class DocumentIconChecker {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Initialize the plugin
        add_action('init', array($this, 'init'));
        
        // Register activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'frontend_enqueue_scripts'));
        add_action('enqueue_block_editor_assets', array($this, 'enqueue_block_editor_assets'));
        
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        
        // Register block
        add_action('init', array($this, 'register_block'));
        
        // AJAX handlers
        add_action('wp_ajax_dic_upload_file', array($this, 'handle_file_upload'));
        add_action('wp_ajax_nopriv_dic_upload_file', array($this, 'handle_file_upload'));
        add_action('wp_ajax_dic_analyze_file', array($this, 'analyze_file'));
        add_action('wp_ajax_nopriv_dic_analyze_file', array($this, 'analyze_file'));
        
        // Admin AJAX handlers
        add_action('wp_ajax_dic_create_table', array($this, 'create_table'));
        add_action('wp_ajax_dic_get_tables', array($this, 'get_tables'));
        add_action('wp_ajax_dic_get_table_entries', array($this, 'get_table_entries'));
    }

    public function init() {
        load_plugin_textdomain('document-icon-checker', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Register block category
        if (function_exists('register_block_type')) {
            add_filter('block_categories_all', function($categories) {
                return array_merge(
                    $categories,
                    array(
                        array(
                            'slug' => 'ai-tools',
                            'title' => __('AI Tools', 'document-icon-checker'),
                            'icon' => 'media-document',
                        ),
                    )
                );
            });
        }
    }

    public function register_block() {
        if (!function_exists('register_block_type')) {
            return;
        }

        register_block_type(DIC_PLUGIN_DIR . 'block.json', array(
            'render_callback' => array($this, 'render_block'),
        ));
    }

    public function enqueue_block_editor_assets() {
        wp_enqueue_script(
            'ai-document-checker-block',
            DIC_PLUGIN_URL . 'assets/js/blocks.js',
            array('wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-api-fetch'),
            DIC_PLUGIN_VERSION
        );

        wp_enqueue_style(
            'ai-document-checker-block-editor',
            DIC_PLUGIN_URL . 'assets/css/blocks-editor.css',
            array(),
            DIC_PLUGIN_VERSION
        );
    }

    public function render_block($attributes) {
        ob_start();
        include DIC_PLUGIN_DIR . 'templates/uploader-block.php';
        return ob_get_clean();
    }

    public function activate() {
        // Create database tables
        $this->create_database_tables();
        
        // Set default options
        $default_options = array(
            'file_size_limit' => 10,
            'email_notification' => false,
            'notification_email' => get_option('admin_email'),
        );
        
        add_option('dic_options', $default_options);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    private function create_database_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Tables table
        $tables_table = $wpdb->prefix . 'dic_tables';
        $tables_sql = "CREATE TABLE IF NOT EXISTS $tables_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            type varchar(50) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Entries table
        $entries_table = $wpdb->prefix . 'dic_entries';
        $entries_sql = "CREATE TABLE IF NOT EXISTS $entries_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            table_id mediumint(9) NOT NULL,
            title varchar(255) NOT NULL,
            keywords text,
            file_path varchar(255),
            file_url varchar(255),
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY table_id (table_id)
        ) $charset_collate;";
        
        // Temporary uploads table
        $temp_uploads_table = $wpdb->prefix . 'dic_temp_uploads';
        $temp_uploads_sql = "CREATE TABLE IF NOT EXISTS $temp_uploads_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            file_path varchar(255) NOT NULL,
            file_url varchar(255) NOT NULL,
            session_id varchar(255) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($tables_sql);
        dbDelta($entries_sql);
        dbDelta($temp_uploads_sql);
    }

    public function add_admin_menu() {
        add_menu_page(
            __('AI Document Checker', 'document-icon-checker'),
            __('AI Document Checker', 'document-icon-checker'),
            'manage_options',
            'document-icon-checker',
            array($this, 'admin_page'),
            'dashicons-media-document',
            30
        );
        
        add_submenu_page(
            'document-icon-checker',
            __('Settings', 'document-icon-checker'),
            __('Settings', 'document-icon-checker'),
            'manage_options',
            'document-icon-checker-settings',
            array($this, 'settings_page')
        );
    }

    public function admin_page() {
        include_once(DIC_PLUGIN_DIR . 'templates/admin-page.php');
    }

    public function settings_page() {
        include_once(DIC_PLUGIN_DIR . 'templates/settings-page.php');
    }

    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'document-icon-checker') === false) {
            return;
        }
        
        wp_enqueue_style('dic-admin-style', DIC_PLUGIN_URL . 'assets/css/admin.css', array(), DIC_PLUGIN_VERSION);
        wp_enqueue_script('dic-admin-script', DIC_PLUGIN_URL . 'assets/js/admin.js', array('jquery', 'wp-api'), DIC_PLUGIN_VERSION, true);
        
        wp_localize_script('dic-admin-script', 'dicAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dic-admin-nonce'),
            'strings' => array(
                'confirmDelete' => __('Are you sure you want to delete this? This action cannot be undone.', 'document-icon-checker'),
                'tableCreated' => __('Table created successfully.', 'document-icon-checker'),
                'tableDeleted' => __('Table deleted successfully.', 'document-icon-checker'),
                'tableRenamed' => __('Table renamed successfully.', 'document-icon-checker'),
                'entryAdded' => __('Entry added successfully.', 'document-icon-checker'),
                'entryUpdated' => __('Entry updated successfully.', 'document-icon-checker'),
                'entryDeleted' => __('Entry deleted successfully.', 'document-icon-checker'),
                'error' => __('An error occurred. Please try again.', 'document-icon-checker'),
            ),
        ));
    }

    public function frontend_enqueue_scripts() {
        wp_enqueue_style('dic-frontend-style', DIC_PLUGIN_URL . 'assets/css/frontend.css', array(), DIC_PLUGIN_VERSION);
        wp_enqueue_script('dic-frontend-script', DIC_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), DIC_PLUGIN_VERSION, true);
        
        wp_localize_script('dic-frontend-script', 'dicFrontend', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dic-frontend-nonce'),
            'strings' => array(
                'uploadSuccess' => __('File uploaded successfully.', 'document-icon-checker'),
                'uploadError' => __('Error uploading file. Please try again.', 'document-icon-checker'),
                'analyzing' => __('Analyzing file...', 'document-icon-checker'),
                'matchFound' => __('Your document matches!', 'document-icon-checker'),
                'noMatch' => __('No match found.', 'document-icon-checker'),
                'dragDrop' => __('Drag & drop files here or click to upload', 'document-icon-checker'),
                'invalidFileType' => __('Invalid file type. Please upload PDF, DOC, DOCX, or image files.', 'document-icon-checker'),
                'fileSizeExceeded' => __('File size exceeds the limit.', 'document-icon-checker'),
            ),
        ));
    }

    public function register_rest_routes() {
        register_rest_route('document-icon-checker/v1', '/tables', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_get_tables'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ));
        
        register_rest_route('document-icon-checker/v1', '/tables/(?P<id>\d+)/entries', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_get_table_entries'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ));
    }

    public function handle_file_upload() {
        check_ajax_referer('dic-frontend-nonce', 'nonce');
        
        if (!isset($_FILES['file'])) {
            wp_send_json_error(array('message' => __('No file uploaded.', 'document-icon-checker')));
        }
        
        $file = $_FILES['file'];
        $file_size_limit = intval(get_option('dic_options')['file_size_limit']) * 1024 * 1024; // Convert MB to bytes
        
        // Check file size
        if ($file['size'] > $file_size_limit) {
            wp_send_json_error(array('message' => __('File size exceeds the limit.', 'document-icon-checker')));
        }
        
        // Check file type
        $allowed_types = array(
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/svg+xml'
        );
        
        if (!in_array($file['type'], $allowed_types)) {
            wp_send_json_error(array('message' => __('Invalid file type.', 'document-icon-checker')));
        }
        
        // Create uploads directory if it doesn't exist
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/dic-temp';
        
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        // Generate a unique filename
        $filename = wp_unique_filename($temp_dir, $file['name']);
        $file_path = $temp_dir . '/' . $filename;
        
        // Move the uploaded file
        if (!move_uploaded_file($file['tmp_name'], $file_path)) {
            wp_send_json_error(array('message' => __('Error saving file.', 'document-icon-checker')));
        }
        
        // Get the file URL
        $file_url = $upload_dir['baseurl'] . '/dic-temp/' . $filename;
        
        // Store the file in the temporary uploads table
        global $wpdb;
        $session_id = session_id();
        
        if (empty($session_id)) {
            session_start();
            $session_id = session_id();
        }
        
        $wpdb->insert(
            $wpdb->prefix . 'dic_temp_uploads',
            array(
                'file_path' => $file_path,
                'file_url' => $file_url,
                'session_id' => $session_id,
            )
        );
        
        $upload_id = $wpdb->insert_id;
        
        wp_send_json_success(array(
            'message' => __('File uploaded successfully.', 'document-icon-checker'),
            'uploadId' => $upload_id,
            'fileUrl' => $file_url,
        ));
    }

    public function analyze_file() {
        check_ajax_referer('dic-frontend-nonce', 'nonce');
        
        if (!isset($_POST['uploadId'])) {
            wp_send_json_error(array('message' => __('Missing required parameters.', 'document-icon-checker')));
        }
        
        $upload_id = intval($_POST['uploadId']);
        $table_ids = array();
        
        if (isset($_POST['tables'])) {
            $tables_json = stripslashes($_POST['tables']);
            $table_ids = json_decode($tables_json, true);
            
            if (!is_array($table_ids)) {
                $table_ids = array();
            }
            
            $table_ids = array_map('intval', $table_ids);
        }
        
        // Get the uploaded file
        global $wpdb;
        $upload = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}dic_temp_uploads WHERE id = %d",
            $upload_id
        ));
        
        if (!$upload) {
            wp_send_json_error(array('message' => __('File not found.', 'document-icon-checker')));
        }
        
        // Get the file extension
        $file_path = $upload->file_path;
        $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        
        // Extract text from the file
        $text = '';
        
        if ($file_extension === 'pdf') {
            $text = $this->extract_text_from_pdf($file_path);
        } elseif ($file_extension === 'doc' || $file_extension === 'docx') {
            $text = $this->extract_text_from_doc($file_path);
        } elseif (in_array($file_extension, array('jpg', 'jpeg', 'png', 'gif', 'svg'))) {
            $text = $this->extract_text_from_image($file_path);
        }
        
        // Search for matches in the selected tables
        $matches = array();
        
        foreach ($table_ids as $table_id) {
            $table = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}dic_tables WHERE id = %d",
                $table_id
            ));
            
            if (!$table) {
                continue;
            }
            
            $entries = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}dic_entries WHERE table_id = %d",
                $table_id
            ));
            
            foreach ($entries as $entry) {
                $keywords = explode(',', $entry->keywords);
                
                foreach ($keywords as $keyword) {
                    $keyword = trim($keyword);
                    
                    if (!empty($keyword) && stripos($text, $keyword) !== false) {
                        $matches[] = array(
                            'table' => $table->name,
                            'entry' => $entry->title,
                            'keyword' => $keyword,
                        );
                        break; // Found a match for this entry, move to the next one
                    }
                }
            }
        }
        
        // Send email notification if enabled
        $options = get_option('dic_options');
        
        if (isset($_POST['enableEmail']) && $_POST['enableEmail'] && !empty($_POST['emailAddress'])) {
            $this->send_email_notification($_POST['emailAddress'], $upload, $matches);
        } elseif ($options['email_notification'] && !empty($options['notification_email'])) {
            $this->send_email_notification($options['notification_email'], $upload, $matches);
        }
        
        wp_send_json_success(array(
            'matches' => $matches,
            'hasMatch' => !empty($matches),
        ));
    }

    private function extract_text_from_pdf($file_path) {
        // In a real implementation, this would use a PDF parsing library
        // For this example, we'll return a placeholder
        return 'This is a sample PDF text for demonstration purposes.';
    }

    private function extract_text_from_doc($file_path) {
        // In a real implementation, this would use a DOC/DOCX parsing library
        // For this example, we'll return a placeholder
        return 'This is a sample DOC/DOCX text for demonstration purposes.';
    }

    private function extract_text_from_image($file_path) {
        // In a real implementation, this would use an OCR or AI image recognition service
        // For this example, we'll return a placeholder
        return 'This is a sample image text for demonstration purposes.';
    }

    private function send_email_notification($email, $upload, $matches) {
        $subject = __('Document Match Notification', 'document-icon-checker');
        
        $message = __('A document has been uploaded and analyzed.', 'document-icon-checker') . "\n\n";
        
        if (!empty($matches)) {
            $message .= __('Matches found:', 'document-icon-checker') . "\n";
            
            foreach ($matches as $match) {
                $message .= sprintf(
                    __('Table: %s, Entry: %s, Keyword: %s', 'document-icon-checker'),
                    $match['table'],
                    $match['entry'],
                    $match['keyword']
                ) . "\n";
            }
        } else {
            $message .= __('No matches found.', 'document-icon-checker') . "\n";
        }
        
        $message .= "\n" . __('The uploaded file is attached.', 'document-icon-checker');
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        $attachments = array($upload->file_path);
        
        wp_mail($email, $subject, $message, $headers, $attachments);
    }

    public function api_get_tables($request) {
        global $wpdb;
        
        $tables = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}dic_tables ORDER BY name ASC"
        );
        
        return rest_ensure_response($tables);
    }

    public function api_get_table_entries($request) {
        $table_id = $request['id'];
        
        global $wpdb;
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}dic_entries WHERE table_id = %d ORDER BY title ASC",
            $table_id
        ));
        
        return rest_ensure_response($entries);
    }

    public function create_table() {
        check_ajax_referer('dic-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'document-icon-checker')));
        }
        
        if (!isset($_POST['name']) || !isset($_POST['type'])) {
            wp_send_json_error(array('message' => __('Missing required parameters.', 'document-icon-checker')));
        }
        
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'dic_tables',
            array(
                'name' => sanitize_text_field($_POST['name']),
                'type' => sanitize_text_field($_POST['type'])
            )
        );
        
        if ($result === false) {
            wp_send_json_error(array('message' => __('Error creating table.', 'document-icon-checker')));
        }
        
        wp_send_json_success(array(
            'id' => $wpdb->insert_id,
            'message' => __('Table created successfully.', 'document-icon-checker')
        ));
    }

    public function get_tables() {
        check_ajax_referer('dic-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'document-icon-checker')));
        }
        
        global $wpdb;
        
        $tables = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}dic_tables ORDER BY name ASC");
        
        wp_send_json_success(array('tables' => $tables));
    }

    public function get_table_entries() {
        check_ajax_referer('dic-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'document-icon-checker')));
        }
        
        if (!isset($_POST['tableId'])) {
            wp_send_json_error(array('message' => __('Missing table ID.', 'document-icon-checker')));
        }
        
        global $wpdb;
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}dic_entries WHERE table_id = %d ORDER BY title ASC",
            intval($_POST['tableId'])
        ));
        
        wp_send_json_success(array('entries' => $entries));
    }
}

// Initialize the plugin
DocumentIconChecker::get_instance();