<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get block attributes
$tables = isset($attributes['tables']) ? $attributes['tables'] : array();
$file_size_limit = isset($attributes['fileSizeLimit']) ? intval($attributes['fileSizeLimit']) : 10;
$enable_email = isset($attributes['enableEmail']) ? $attributes['enableEmail'] : false;
$email_address = isset($attributes['emailAddress']) ? $attributes['emailAddress'] : '';
$title = isset($attributes['title']) ? $attributes['title'] : __('Document Checker', 'document-icon-checker');
$description = isset($attributes['description']) ? $attributes['description'] : __('Upload your document to check it against our database', 'document-icon-checker');
$button_text = isset($attributes['buttonText']) ? $attributes['buttonText'] : __('Check Document', 'document-icon-checker');

// Generate a unique ID for this uploader instance
$uploader_id = 'dic-uploader-' . uniqid();
?>

<div class="dic-uploader-container" 
     id="<?php echo esc_attr($uploader_id); ?>"
     data-tables="<?php echo esc_attr(json_encode($tables)); ?>"
     data-file-size-limit="<?php echo esc_attr($file_size_limit); ?>"
     data-enable-email="<?php echo esc_attr($enable_email ? '1' : '0'); ?>"
     data-email-address="<?php echo esc_attr($email_address); ?>"
     data-button-text="<?php echo esc_attr($button_text); ?>">
    
    <div class="dic-uploader-header">
        <h2 class="dic-uploader-title"><?php echo esc_html($title); ?></h2>
        <p class="dic-uploader-description"><?php echo esc_html($description); ?></p>
    </div>

    <!-- Upload Section -->
    <div class="dic-upload-section">
        <!-- Upload Box -->
        <div class="dic-uploader-box">
            <div class="dic-uploader-dropzone">
                <div class="dic-uploader-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" y1="3" x2="12" y2="15"></line>
                    </svg>
                </div>
                <div class="dic-uploader-text">
                    <?php _e('Drag & drop files here or click to upload', 'document-icon-checker'); ?>
                </div>
                <div class="dic-uploader-info">
                    <?php printf(__('Allowed file types: PDF, DOC, DOCX, Images | Max size: %dMB', 'document-icon-checker'), $file_size_limit); ?>
                </div>
            </div>
            
            <input type="file" class="dic-file-input" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif,.svg">
            
            <!-- Selected File Display -->
            <div class="dic-selected-file">
                <div class="dic-file-info">
                    <div class="dic-file-icon"></div>
                    <div class="dic-file-details">
                        <div class="dic-file-name"></div>
                        <div class="dic-file-size"></div>
                    </div>
                    <button type="button" class="dic-file-remove" aria-label="<?php esc_attr_e('Remove file', 'document-icon-checker'); ?>">×</button>
                </div>
            </div>
        </div>

        <!-- Check Document Button -->
        <div class="dic-check-button-container">
            <button type="button" class="dic-check-button">
                <?php echo esc_html($button_text); ?>
            </button>
        </div>
    </div>
    
    <!-- Progress Bar -->
    <div class="dic-uploader-progress">
        <div class="dic-progress-bar">
            <div class="dic-progress-bar-inner"></div>
        </div>
        <div class="dic-progress-text">0%</div>
    </div>
    
    <!-- Results Box -->
    <div class="dic-uploader-result">
        <div class="dic-result-icon">
            <svg class="dic-result-success" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
            </svg>
            <svg class="dic-result-error" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="15" y1="9" x2="9" y2="15"></line>
                <line x1="9" y1="9" x2="15" y2="15"></line>
            </svg>
        </div>
        <div class="dic-result-message"></div>
        <div class="dic-result-details"></div>
        <button type="button" class="dic-reset-button">
            <?php _e('Upload Another Document', 'document-icon-checker'); ?>
        </button>
    </div>
</div>