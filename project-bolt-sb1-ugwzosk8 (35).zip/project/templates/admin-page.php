<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap dic-admin-page">
    <h1><?php _e('AI DocChecker', 'document-icon-checker'); ?></h1>
    
    <div class="dic-admin-tabs">
        <div class="dic-tab-nav">
            <button class="dic-tab-button active" data-tab="tables"><?php _e('Tables', 'document-icon-checker'); ?></button>
            <button class="dic-tab-button" data-tab="entries"><?php _e('Entries', 'document-icon-checker'); ?></button>
        </div>
        
        <div class="dic-tab-content active" id="dic-tab-tables">
            <div class="dic-section-header">
                <h2><?php _e('Tables', 'document-icon-checker'); ?></h2>
                <button class="button button-primary" id="dic-add-table"><?php _e('Add New Table', 'document-icon-checker'); ?></button>
            </div>
            
            <div class="dic-tables-list">
                <div class="dic-loading"><?php _e('Loading tables...', 'document-icon-checker'); ?></div>
                <table class="wp-list-table widefat fixed striped" style="display: none;">
                    <thead>
                        <tr>
                            <th><?php _e('Name', 'document-icon-checker'); ?></th>
                            <th><?php _e('Type', 'document-icon-checker'); ?></th>
                            <th><?php _e('Created', 'document-icon-checker'); ?></th>
                            <th><?php _e('Actions', 'document-icon-checker'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="dic-tables-list-body">
                        <!-- Tables will be loaded here -->
                    </tbody>
                </table>
                <div class="dic-no-tables" style="display: none;">
                    <p><?php _e('No tables found. Click "Add New Table" to create one.', 'document-icon-checker'); ?></p>
                </div>
            </div>
        </div>
        
        <div class="dic-tab-content" id="dic-tab-entries">
            <div class="dic-section-header">
                <h2><?php _e('Entries', 'document-icon-checker'); ?></h2>
                <div class="dic-table-selector">
                    <label for="dic-select-table"><?php _e('Select Table:', 'document-icon-checker'); ?></label>
                    <select id="dic-select-table">
                        <option value=""><?php _e('-- Select a table --', 'document-icon-checker'); ?></option>
                    </select>
                    <button class="button button-primary" id="dic-add-entry" disabled><?php _e('Add New Entry', 'document-icon-checker'); ?></button>
                </div>
            </div>
            
            <div class="dic-entries-list">
                <div class="dic-select-table-message"><?php _e('Please select a table to view entries.', 'document-icon-checker'); ?></div>
                <div class="dic-loading" style="display: none;"><?php _e('Loading entries...', 'document-icon-checker'); ?></div>
                <table class="wp-list-table widefat fixed striped" style="display: none;">
                    <thead>
                        <tr>
                            <th><?php _e('Title', 'document-icon-checker'); ?></th>
                            <th><?php _e('Keywords', 'document-icon-checker'); ?></th>
                            <th><?php _e('File', 'document-icon-checker'); ?></th>
                            <th><?php _e('Actions', 'document-icon-checker'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="dic-entries-list-body">
                        <!-- Entries will be loaded here -->
                    </tbody>
                </table>
                <div class="dic-no-entries" style="display: none;">
                    <p><?php _e('No entries found in this table. Click "Add New Entry" to create one.', 'document-icon-checker'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Table Modal -->
<div id="dic-add-table-modal" class="dic-modal">
    <div class="dic-modal-content">
        <span class="dic-modal-close">&times;</span>
        <h2><?php _e('Add New Table', 'document-icon-checker'); ?></h2>
        <form id="dic-add-table-form">
            <div class="dic-form-group">
                <label for="dic-table-name"><?php _e('Table Name:', 'document-icon-checker'); ?></label>
                <input type="text" id="dic-table-name" name="name" required>
            </div>
            <div class="dic-form-group">
                <label><?php _e('Table Type:', 'document-icon-checker'); ?></label>
                <div class="dic-radio-group">
                    <label>
                        <input type="radio" name="type" value="documents" checked>
                        <?php _e('Documents Table (keywords & values)', 'document-icon-checker'); ?>
                    </label>
                    <label>
                        <input type="radio" name="type" value="icons">
                        <?php _e('Icons, Stamps & Shapes Table', 'document-icon-checker'); ?>
                    </label>
                </div>
            </div>
            <div class="dic-form-actions">
                <button type="submit" class="button button-primary"><?php _e('Create Table', 'document-icon-checker'); ?></button>
                <button type="button" class="button dic-modal-cancel"><?php _e('Cancel', 'document-icon-checker'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Rename Table Modal -->
<div id="dic-rename-table-modal" class="dic-modal">
    <div class="dic-modal-content">
        <span class="dic-modal-close">&times;</span>
        <h2><?php _e('Rename Table', 'document-icon-checker'); ?></h2>
        <form id="dic-rename-table-form">
            <input type="hidden" id="dic-rename-table-id" name="tableId">
            <div class="dic-form-group">
                <label for="dic-rename-table-name"><?php _e('Table Name:', 'document-icon-checker'); ?></label>
                <input type="text" id="dic-rename-table-name" name="name" required>
            </div>
            <div class="dic-form-actions">
                <button type="submit" class="button button-primary"><?php _e('Rename Table', 'document-icon-checker'); ?></button>
                <button type="button" class="button dic-modal-cancel"><?php _e('Cancel', 'document-icon-checker'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Add Entry Modal -->
<div id="dic-add-entry-modal" class="dic-modal">
    <div class="dic-modal-content">
        <span class="dic-modal-close">&times;</span>
        <h2><?php _e('Add New Entry', 'document-icon-checker'); ?></h2>
        <form id="dic-add-entry-form" enctype="multipart/form-data">
            <input type="hidden" id="dic-entry-table-id" name="tableId">
            <div class="dic-form-group">
                <label for="dic-entry-title"><?php _e('Title:', 'document-icon-checker'); ?></label>
                <input type="text" id="dic-entry-title" name="title" required>
            </div>
            <div class="dic-form-group">
                <label for="dic-entry-keywords"><?php _e('Keywords (comma-separated):', 'document-icon-checker'); ?></label>
                <textarea id="dic-entry-keywords" name="keywords" rows="4"></textarea>
            </div>
            <div class="dic-form-group">
                <label for="dic-entry-file"><?php _e('File (optional):', 'document-icon-checker'); ?></label>
                <input type="file" id="dic-entry-file" name="file">
                <p class="description"><?php _e('Allowed file types: PDF, DOC, DOCX, JPG, PNG, GIF, SVG', 'document-icon-checker'); ?></p>
            </div>
            <div class="dic-form-actions">
                <button type="submit" class="button button-primary"><?php _e('Add Entry', 'document-icon-checker'); ?></button>
                <button type="button" class="button dic-modal-cancel"><?php _e('Cancel', 'document-icon-checker'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Entry Modal -->
<div id="dic-edit-entry-modal" class="dic-modal">
    <div class="dic-modal-content">
        <span class="dic-modal-close">&times;</span>
        <h2><?php _e('Edit Entry', 'document-icon-checker'); ?></h2>
        <form id="dic-edit-entry-form" enctype="multipart/form-data">
            <input type="hidden" id="dic-edit-entry-id" name="entryId">
            <div class="dic-form-group">
                <label for="dic-edit-entry-title"><?php _e('Title:', 'document-icon-checker'); ?></label>
                <input type="text" id="dic-edit-entry-title" name="title" required>
            </div>
            <div class="dic-form-group">
                <label for="dic-edit-entry-keywords"><?php _e('Keywords (comma-separated):', 'document-icon-checker'); ?></label>
                <textarea id="dic-edit-entry-keywords" name="keywords" rows="4"></textarea>
            </div>
            <div class="dic-form-group">
                <label for="dic-edit-entry-file"><?php _e('File (optional):', 'document-icon-checker'); ?></label>
                <input type="file" id="dic-edit-entry-file" name="file">
                <p class="description"><?php _e('Allowed file types: PDF, DOC, DOCX, JPG, PNG, GIF, SVG', 'document-icon-checker'); ?></p>
                <div id="dic-edit-entry-current-file" style="display: none;">
                    <p><?php _e('Current file:', 'document-icon-checker'); ?> <a href="#" target="_blank" id="dic-edit-entry-file-link"></a></p>
                </div>
            </div>
            <div class="dic-form-actions">
                <button type="submit" class="button button-primary"><?php _e('Update Entry', 'document-icon-checker'); ?></button>
                <button type="button" class="button dic-modal-cancel"><?php _e('Cancel', 'document-icon-checker'); ?></button>
            </div>
        </form>
    </div>
</div>