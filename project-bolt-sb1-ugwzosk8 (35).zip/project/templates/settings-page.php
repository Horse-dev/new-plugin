<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

$options = get_option('dic_options', array(
    'file_size_limit' => 10,
    'email_notification' => false,
    'notification_email' => get_option('admin_email'),
));
?>

<div class="wrap dic-settings-page">
    <h1><?php _e('AI DocChecker Settings', 'document-icon-checker'); ?></h1>
    
    <form method="post" action="options.php" id="dic-settings-form">
        <?php settings_fields('dic_options_group'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="dic-file-size-limit"><?php _e('File Size Limit (MB)', 'document-icon-checker'); ?></label>
                </th>
                <td>
                    <input type="number" id="dic-file-size-limit" name="dic_options[file_size_limit]" value="<?php echo esc_attr($options['file_size_limit']); ?>" min="1" max="50">
                    <p class="description"><?php _e('Maximum file size for uploads (in MB).', 'document-icon-checker'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="dic-email-notification"><?php _e('Email Notification', 'document-icon-checker'); ?></label>
                </th>
                <td>
                    <label>
                        <input type="checkbox" id="dic-email-notification" name="dic_options[email_notification]" value="1" <?php checked($options['email_notification'], true); ?>>
                        <?php _e('Enable email notifications for file uploads', 'document-icon-checker'); ?>
                    </label>
                </td>
            </tr>
            <tr id="dic-notification-email-row" <?php echo $options['email_notification'] ? '' : 'style="display: none;"'; ?>>
                <th scope="row">
                    <label for="dic-notification-email"><?php _e('Notification Email', 'document-icon-checker'); ?></label>
                </th>
                <td>
                    <input type="email" id="dic-notification-email" name="dic_options[notification_email]" value="<?php echo esc_attr($options['notification_email']); ?>" class="regular-text">
                    <p class="description"><?php _e('Email address to receive notifications.', 'document-icon-checker'); ?></p>
                </td>
            </tr>
        </table>
        
        <?php submit_button(); ?>
    </form>
</div>

<script>
    jQuery(document).ready(function($) {
        $('#dic-email-notification').on('change', function() {
            if ($(this).is(':checked')) {
                $('#dic-notification-email-row').show();
            } else {
                $('#dic-notification-email-row').hide();
            }
        });
    });
</script>

<?php
// Register settings
add_action('admin_init', 'dic_register_settings');

function dic_register_settings() {
    register_setting('dic_options_group', 'dic_options', 'dic_sanitize_options');
}

function dic_sanitize_options($options) {
    $options['file_size_limit'] = intval($options['file_size_limit']);
    
    if ($options['file_size_limit'] < 1) {
        $options['file_size_limit'] = 1;
    } elseif ($options['file_size_limit'] > 50) {
        $options['file_size_limit'] = 50;
    }
    
    $options['email_notification'] = isset($options['email_notification']) ? true : false;
    $options['notification_email'] = sanitize_email($options['notification_email']);
    
    return $options;
}
?>