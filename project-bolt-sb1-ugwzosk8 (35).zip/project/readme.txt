=== AI DocChecker ===
Contributors: horsedevteam
Tags: document, file, upload, ai, analysis, gutenberg
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.9.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin that allows users to upload files and compares them against admin-defined records using AI.

== Description ==

The AI DocChecker plugin provides a powerful way to analyze uploaded files against your database of documents, icons, stamps, and shapes. It's perfect for organizations that need to verify document authenticity or identify specific elements within uploaded files.

= Key Features =

* **Admin Panel with Flexible Table Management**
  * Create multiple tables for different document types
  * Two table types: Documents Table (with keywords & values) and Icons, Stamps & Shapes Table
  * Edit, delete, rename tables, and modify entries
  * Store uploaded files securely in WordPress

* **User-Friendly Frontend Upload**
  * Drag & drop or click to upload files
  * Support for PDF, DOC, DOCX, and various image formats
  * Customizable file size limits
  * Temporary file storage (deleted on page refresh)
  * Clear success/failure indicators

* **Gutenberg Block Integration**
  * Insert the upload box as a Gutenberg block
  * Select which tables to compare against
  * Customize file size limits and email notifications

* **AI Comparison & Matching Logic**
  * Text extraction from documents
  * Keyword matching against stored records
  * Image analysis for icons, stamps, and shapes

* **Email Notification System**
  * Optional email notifications for matches
  * Customizable recipient email address
  * Includes match details and the uploaded file

= Use Cases =

* Document verification systems
* Form processing with specific requirements
* Legal document validation
* Brand asset compliance checking
* Educational assessment tools

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/document-icon-checker` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the 'AI DocChecker' menu in your admin sidebar to configure tables and entries.
4. Add the "AI Document" block to your pages or posts.

== Frequently Asked Questions ==

= How does the AI analyze documents? =

The plugin extracts text from documents and compares it against keywords stored in your database. For images, it identifies visual elements and matches them against your stored icons, stamps, and shapes.

= Are uploaded files stored permanently? =

Files uploaded by users are stored temporarily and deleted when the page is refreshed. Files uploaded by admins for reference are stored permanently in the WordPress media library.

= Can I customize the appearance of the uploader? =

Yes, you can customize the appearance using CSS. The plugin provides CSS classes for all elements.

= Does this work with page builders? =

Yes, the plugin is compatible with most page builders through its Gutenberg block. It also integrates with JetFormBuilder.

= What file types are supported? =

The plugin supports PDF, DOC, DOCX, and various image formats (JPG, PNG, GIF, SVG, etc.).

== Screenshots ==

1. Admin panel for managing tables and entries
2. Gutenberg block settings
3. Frontend file uploader
4. Successful match result
5. Settings page

== Changelog ==

= 1.9.0 =
* Updated plugin version number
* Enhanced Gutenberg block integration
* Improved JetFormBuilder compatibility
* Fixed block registration issues
* Updated block preview styling

= 1.8.0 =
* Updated plugin version number
* Fixed Gutenberg block integration
* Improved block registration
* Enhanced file handling
* Renamed block to "AI Document"

[Previous changelog entries remain the same...]

== Upgrade Notice ==

= 1.9.0 =
This version includes improvements to the Gutenberg block integration and JetFormBuilder compatibility. The block preview has been enhanced for better visual feedback.

[Previous upgrade notices remain the same...]