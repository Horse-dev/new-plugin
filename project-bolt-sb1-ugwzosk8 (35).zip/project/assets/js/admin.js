/**
 * Admin JavaScript for AI DocChecker
 */
(function($) {
    'use strict';

    // DOM elements
    const $tabButtons = $('.dic-tab-button');
    const $tabContents = $('.dic-tab-content');
    const $addTableButton = $('#dic-add-table');
    const $addTableModal = $('#dic-add-table-modal');
    const $addTableForm = $('#dic-add-table-form');
    const $renameTableModal = $('#dic-rename-table-modal');
    const $renameTableForm = $('#dic-rename-table-form');
    const $selectTable = $('#dic-select-table');
    const $addEntryButton = $('#dic-add-entry');
    const $addEntryModal = $('#dic-add-entry-modal');
    const $addEntryForm = $('#dic-add-entry-form');
    const $editEntryModal = $('#dic-edit-entry-modal');
    const $editEntryForm = $('#dic-edit-entry-form');
    const $tablesListBody = $('#dic-tables-list-body');
    const $entriesListBody = $('#dic-entries-list-body');
    const $modalCloseButtons = $('.dic-modal-close, .dic-modal-cancel');

    // Initialize
    $(document).ready(function() {
        loadTables();
        bindEvents();
    });

    // Bind events
    function bindEvents() {
        // Tab navigation
        $tabButtons.on('click', function() {
            const tabId = $(this).data('tab');
            $tabButtons.removeClass('active');
            $tabContents.removeClass('active');
            $(this).addClass('active');
            $(`#dic-tab-${tabId}`).addClass('active');
        });

        // Modal open/close
        $addTableButton.on('click', function() {
            $addTableModal.show();
        });

        $modalCloseButtons.on('click', function() {
            $(this).closest('.dic-modal').hide();
        });

        $(window).on('click', function(event) {
            if ($(event.target).hasClass('dic-modal')) {
                $('.dic-modal').hide();
            }
        });

        // Table selection for entries
        $selectTable.on('change', function() {
            const tableId = $(this).val();
            
            if (tableId) {
                $addEntryButton.prop('disabled', false);
                loadTableEntries(tableId);
            } else {
                $addEntryButton.prop('disabled', true);
                $('.dic-entries-list .dic-select-table-message').show();
                $('.dic-entries-list .dic-loading, .dic-entries-list table, .dic-entries-list .dic-no-entries').hide();
            }
        });

        // Add entry button
        $addEntryButton.on('click', function() {
            const tableId = $selectTable.val();
            $('#dic-entry-table-id').val(tableId);
            $addEntryModal.show();
        });

        // Form submissions
        $addTableForm.on('submit', function(e) {
            e.preventDefault();
            createTable();
        });

        $renameTableForm.on('submit', function(e) {
            e.preventDefault();
            renameTable();
        });

        $addEntryForm.on('submit', function(e) {
            e.preventDefault();
            addEntry();
        });

        $editEntryForm.on('submit', function(e) {
            e.preventDefault();
            updateEntry();
        });
    }

    // Load tables
    function loadTables() {
        $('.dic-tables-list .dic-loading').show();
        $('.dic-tables-list table, .dic-tables-list .dic-no-tables').hide();

        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dic_get_tables',
                nonce: dicAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderTables(response.data.tables);
                    populateTableSelect(response.data.tables);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            },
            complete: function() {
                $('.dic-tables-list .dic-loading').hide();
            }
        });
    }

    // Render tables
    function renderTables(tables) {
        $tablesListBody.empty();
        
        if (tables.length === 0) {
            $('.dic-tables-list .dic-no-tables').show();
            return;
        }
        
        tables.forEach(function(table) {
            const tableType = table.type === 'documents' ? 
                'Documents Table' : 
                'Icons, Stamps & Shapes Table';
            
            const row = `
                <tr data-id="${table.id}">
                    <td>${table.name}</td>
                    <td>${tableType}</td>
                    <td>${formatDate(table.created_at)}</td>
                    <td>
                        <button class="button dic-rename-table" data-id="${table.id}" data-name="${table.name}">Rename</button>
                        <button class="button dic-delete-table" data-id="${table.id}">Delete</button>
                    </td>
                </tr>
            `;
            
            $tablesListBody.append(row);
        });
        
        $('.dic-tables-list table').show();
        
        // Bind events to the new buttons
        $('.dic-rename-table').on('click', function() {
            const tableId = $(this).data('id');
            const tableName = $(this).data('name');
            
            $('#dic-rename-table-id').val(tableId);
            $('#dic-rename-table-name').val(tableName);
            
            $renameTableModal.show();
        });
        
        $('.dic-delete-table').on('click', function() {
            const tableId = $(this).data('id');
            
            if (confirm(dicAdmin.strings.confirmDelete)) {
                deleteTable(tableId);
            }
        });
    }

    // Populate table select
    function populateTableSelect(tables) {
        $selectTable.empty();
        $selectTable.append('<option value="">' + '-- Select a table --' + '</option>');
        
        tables.forEach(function(table) {
            $selectTable.append(`<option value="${table.id}">${table.name}</option>`);
        });
    }

    // Load table entries
    function loadTableEntries(tableId) {
        $('.dic-entries-list .dic-select-table-message').hide();
        $('.dic-entries-list .dic-loading').show();
        $('.dic-entries-list table, .dic-entries-list .dic-no-entries').hide();

        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dic_get_table_entries',
                nonce: dicAdmin.nonce,
                tableId: tableId
            },
            success: function(response) {
                if (response.success) {
                    renderEntries(response.data.entries);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            },
            complete: function() {
                $('.dic-entries-list .dic-loading').hide();
            }
        });
    }

    // Render entries
    function renderEntries(entries) {
        $entriesListBody.empty();
        
        if (entries.length === 0) {
            $('.dic-entries-list .dic-no-entries').show();
            return;
        }
        
        entries.forEach(function(entry) {
            const fileLink = entry.file_url ? 
                `<a href="${entry.file_url}" target="_blank">View File</a>` : 
                'No file';
            
            const row = `
                <tr data-id="${entry.id}">
                    <td>${entry.title}</td>
                    <td>${entry.keywords || 'None'}</td>
                    <td>${fileLink}</td>
                    <td>
                        <button class="button dic-edit-entry" data-id="${entry.id}" data-title="${entry.title}" data-keywords="${entry.keywords || ''}" data-file-url="${entry.file_url || ''}">Edit</button>
                        <button class="button dic-delete-entry" data-id="${entry.id}">Delete</button>
                    </td>
                </tr>
            `;
            
            $entriesListBody.append(row);
        });
        
        $('.dic-entries-list table').show();
        
        // Bind events to the new buttons
        $('.dic-edit-entry').on('click', function() {
            const entryId = $(this).data('id');
            const entryTitle = $(this).data('title');
            const entryKeywords = $(this).data('keywords');
            const entryFileUrl = $(this).data('file-url');
            
            $('#dic-edit-entry-id').val(entryId);
            $('#dic-edit-entry-title').val(entryTitle);
            $('#dic-edit-entry-keywords').val(entryKeywords);
            
            if (entryFileUrl) {
                $('#dic-edit-entry-file-link').attr('href', entryFileUrl).text(entryFileUrl.split('/').pop());
                $('#dic-edit-entry-current-file').show();
            } else {
                $('#dic-edit-entry-current-file').hide();
            }
            
            $editEntryModal.show();
        });
        
        $('.dic-delete-entry').on('click', function() {
            const entryId = $(this).data('id');
            
            if (confirm(dicAdmin.strings.confirmDelete)) {
                deleteEntry(entryId);
            }
        });
    }

    // Create table
    function createTable() {
        const formData = new FormData($addTableForm[0]);
        formData.append('action', 'dic_create_table');
        formData.append('nonce', dicAdmin.nonce);

        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $addTableModal.hide();
                    $addTableForm[0].reset();
                    loadTables();
                    alert(dicAdmin.strings.tableCreated);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                alert(dicAdmin.strings.error + " Details: " + error);
            }
        });
    }

    // Rename table
    function renameTable() {
        const formData = new FormData($renameTableForm[0]);
        formData.append('action', 'dic_rename_table');
        formData.append('nonce', dicAdmin.nonce);

        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $renameTableModal.hide();
                    loadTables();
                    alert(dicAdmin.strings.tableRenamed);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            }
        });
    }

    // Delete table
    function deleteTable(tableId) {
        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dic_delete_table',
                nonce: dicAdmin.nonce,
                tableId: tableId
            },
            success: function(response) {
                if (response.success) {
                    loadTables();
                    alert(dicAdmin.strings.tableDeleted);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            }
        });
    }

    // Add entry
    function addEntry() {
        const formData = new FormData($addEntryForm[0]);
        formData.append('action', 'dic_add_entry');
        formData.append('nonce', dicAdmin.nonce);

        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $addEntryModal.hide();
                    $addEntryForm[0].reset();
                    loadTableEntries($selectTable.val());
                    alert(dicAdmin.strings.entryAdded);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            }
        });
    }

    // Update entry
    function updateEntry() {
        const formData = new FormData($editEntryForm[0]);
        formData.append('action', 'dic_update_entry');
        formData.append('nonce', dicAdmin.nonce);

        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $editEntryModal.hide();
                    loadTableEntries($selectTable.val());
                    alert(dicAdmin.strings.entryUpdated);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            }
        });
    }

    // Delete entry
    function deleteEntry(entryId) {
        $.ajax({
            url: dicAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'dic_delete_entry',
                nonce: dicAdmin.nonce,
                entryId: entryId
            },
            success: function(response) {
                if (response.success) {
                    loadTableEntries($selectTable.val());
                    alert(dicAdmin.strings.entryDeleted);
                } else {
                    alert(response.data.message || dicAdmin.strings.error);
                }
            },
            error: function() {
                alert(dicAdmin.strings.error);
            }
        });
    }

    // Format date
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }

})(jQuery);