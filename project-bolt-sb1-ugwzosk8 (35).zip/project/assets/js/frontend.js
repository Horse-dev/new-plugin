/**
 * Frontend JavaScript for Document Checker
 */
(function($) {
    'use strict';

    // Initialize all uploaders on the page
    $(document).ready(function() {
        $('.dic-uploader-container').each(function() {
            initUploader($(this));
        });
    });

    // Initialize uploader
    function initUploader($container) {
        const $uploadSection = $container.find('.dic-upload-section');
        const $dropzone = $container.find('.dic-uploader-dropzone');
        const $fileInput = $container.find('.dic-file-input');
        const $uploaderBox = $container.find('.dic-uploader-box');
        const $selectedFile = $container.find('.dic-selected-file');
        const $fileName = $container.find('.dic-file-name');
        const $fileSize = $container.find('.dic-file-size');
        const $fileRemove = $container.find('.dic-file-remove');
        const $checkButton = $container.find('.dic-check-button');
        const $progress = $container.find('.dic-uploader-progress');
        const $progressBar = $container.find('.dic-progress-bar-inner');
        const $progressText = $container.find('.dic-progress-text');
        const $result = $container.find('.dic-uploader-result');
        const $resultSuccess = $container.find('.dic-result-success');
        const $resultError = $container.find('.dic-result-error');
        const $resultMessage = $container.find('.dic-result-message');
        const $resultDetails = $container.find('.dic-result-details');
        const $resetButton = $container.find('.dic-reset-button');
        
        // Get configuration from data attributes
        const tables = JSON.parse($container.attr('data-tables') || '[]');
        const fileSizeLimit = parseInt($container.attr('data-file-size-limit') || '10', 10);
        const enableEmail = $container.attr('data-enable-email') === '1';
        const emailAddress = $container.attr('data-email-address') || '';

        // Prevent default drag behaviors
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            $dropzone[0].addEventListener(eventName, preventDefaults, false);
            document.body.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        // Handle drag enter/leave effects
        ['dragenter', 'dragover'].forEach(eventName => {
            $dropzone[0].addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            $dropzone[0].addEventListener(eventName, unhighlight, false);
        });

        function highlight() {
            $uploaderBox.addClass('drag-over');
        }

        function unhighlight() {
            $uploaderBox.removeClass('drag-over');
        }

        // Handle dropped files
        $dropzone[0].addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;

            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        }

        // Make the entire dropzone clickable
        $dropzone.on('click', function(e) {
            e.preventDefault();
            $fileInput.trigger('click');
        });

        // Handle file selection
        $fileInput.on('change', function(e) {
            if (this.files && this.files.length > 0) {
                handleFileSelect(this.files[0]);
            }
        });

        // Handle file removal
        $fileRemove.on('click', function(e) {
            e.preventDefault();
            resetUploader();
        });

        // Handle check button click
        $checkButton.on('click', function(e) {
            e.preventDefault();
            const file = $fileInput[0].files[0];
            if (file) {
                uploadAndAnalyzeFile(file);
            }
        });

        // Handle reset button click
        $resetButton.on('click', function(e) {
            e.preventDefault();
            resetUploader();
            showUploader();
        });

        function handleFileSelect(file) {
            // Validate file type
            const allowedTypes = [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'image/jpeg',
                'image/png',
                'image/gif',
                'image/svg+xml'
            ];

            // Safari fix: also check file extension
            const fileExtension = file.name.split('.').pop().toLowerCase();
            const allowedExtensions = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'gif', 'svg'];

            if (!allowedTypes.includes(file.type) && !allowedExtensions.includes(fileExtension)) {
                showError(dicFrontend.strings.invalidFileType);
                return;
            }

            // Validate file size
            if (file.size > fileSizeLimit * 1024 * 1024) {
                showError(dicFrontend.strings.fileSizeExceeded);
                return;
            }

            // Update file preview
            $fileName.text(file.name);
            $fileSize.text(formatFileSize(file.size));
            updateFileIcon(file.type, fileExtension);
            
            // Show file preview and check button
            $selectedFile.show();
            $checkButton.css('display', 'inline-flex');
            $result.hide();
        }

        function uploadAndAnalyzeFile(file) {
            // Hide upload section and show progress
            $uploadSection.addClass('hidden');
            $progress.show();
            updateProgress(0);

            // Create form data
            const formData = new FormData();
            formData.append('action', 'dic_upload_file');
            formData.append('nonce', dicFrontend.nonce);
            formData.append('file', file);

            // Safari fix: ensure proper XHR handling
            $.ajax({
                url: dicFrontend.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                xhr: function() {
                    const xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) {
                            const percent = Math.round((e.loaded / e.total) * 100);
                            updateProgress(percent);
                        }
                    }, false);
                    return xhr;
                },
                success: function(response) {
                    if (response.success) {
                        analyzeFile(response.data.uploadId);
                    } else {
                        showError(response.data.message || dicFrontend.strings.uploadError);
                    }
                },
                error: function() {
                    showError(dicFrontend.strings.uploadError);
                }
            });
        }

        function analyzeFile(uploadId) {
            updateProgress(100);
            $progressText.text(dicFrontend.strings.analyzing);

            const formData = new FormData();
            formData.append('action', 'dic_analyze_file');
            formData.append('nonce', dicFrontend.nonce);
            formData.append('uploadId', uploadId);
            formData.append('tables', JSON.stringify(tables));
            formData.append('enableEmail', enableEmail ? '1' : '0');
            formData.append('emailAddress', emailAddress);

            $.ajax({
                url: dicFrontend.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        showResult(response.data);
                    } else {
                        showError(response.data.message || dicFrontend.strings.uploadError);
                    }
                },
                error: function() {
                    showError(dicFrontend.strings.uploadError);
                }
            });
        }

        function showResult(data) {
            $progress.hide();
            $result.show();

            if (data.hasMatch) {
                $resultSuccess.show();
                $resultError.hide();
                $resultMessage.text(dicFrontend.strings.matchFound);

                // Show match details
                $resultDetails.empty();
                data.matches.forEach(function(match) {
                    const matchHtml = `
                        <div class="dic-match-item">
                            <div><span class="dic-match-table">${escapeHtml(match.table)}</span></div>
                            <div>Entry: <span class="dic-match-entry">${escapeHtml(match.entry)}</span></div>
                            <div>Matched keyword: <span class="dic-match-keyword">${escapeHtml(match.keyword)}</span></div>
                        </div>
                    `;
                    $resultDetails.append(matchHtml);
                });
                $resultDetails.show();
            } else {
                $resultSuccess.hide();
                $resultError.show();
                $resultMessage.text(dicFrontend.strings.noMatch);
                $resultDetails.hide();
            }
        }

        function showError(message) {
            $progress.hide();
            $result.show();
            $resultSuccess.hide();
            $resultError.show();
            $resultMessage.text(message);
            $resultDetails.hide();
        }

        function updateProgress(percent) {
            $progressBar.css('width', percent + '%');
            $progressText.text(percent + '%');
        }

        function resetUploader() {
            $fileInput.val('');
            $selectedFile.hide();
            $progress.hide();
            $result.hide();
            $checkButton.hide();
        }

        function showUploader() {
            $uploadSection.removeClass('hidden');
            $dropzone.show();
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        function updateFileIcon(fileType, fileExtension) {
            const $fileIcon = $container.find('.dic-file-icon');
            let iconHtml = '';

            // Safari fix: check both MIME type and extension
            const isImage = fileType.startsWith('image/') || ['jpg', 'jpeg', 'png', 'gif', 'svg'].includes(fileExtension);
            const isPDF = fileType === 'application/pdf' || fileExtension === 'pdf';

            if (isImage) {
                iconHtml = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
            } else if (isPDF) {
                iconHtml = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>';
            } else {
                iconHtml = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
            }

            $fileIcon.html(iconHtml);
        }

        // Helper function to escape HTML and prevent XSS
        function escapeHtml(unsafe) {
            return unsafe
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }
    }
})(jQuery);