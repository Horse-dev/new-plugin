import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, TextControl, TextareaControl, ToggleControl, RangeControl, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

registerBlockType('document-checker/uploader', {
    apiVersion: 2,
    title: __('Document Checker', 'document-icon-checker'),
    description: __('Add a document upload and analysis field', 'document-icon-checker'),
    category: 'ai-tools',
    icon: 'media-document',
    supports: {
        html: false,
        multiple: false,
        jetFormBuilder: true
    },
    attributes: {
        tables: {
            type: 'array',
            default: []
        },
        fileSizeLimit: {
            type: 'number',
            default: 10
        },
        enableEmail: {
            type: 'boolean',
            default: false
        },
        emailAddress: {
            type: 'string',
            default: ''
        },
        title: {
            type: 'string',
            default: __('Document Checker', 'document-icon-checker')
        },
        description: {
            type: 'string',
            default: __('Upload your document to check it against our database', 'document-icon-checker')
        },
        buttonText: {
            type: 'string',
            default: __('Check Document', 'document-icon-checker')
        }
    },

    edit: ({ attributes, setAttributes }) => {
        const { tables, fileSizeLimit, enableEmail, emailAddress, title, description, buttonText } = attributes;
        const [availableTables, setAvailableTables] = useState([]);
        const blockProps = useBlockProps();

        useEffect(() => {
            apiFetch({ path: '/document-icon-checker/v1/tables' })
                .then(response => {
                    setAvailableTables(response.map(table => ({
                        label: table.name,
                        value: table.id
                    })));
                })
                .catch(error => {
                    console.error('Error loading tables:', error);
                });
        }, []);

        return (
            <div {...blockProps}>
                <InspectorControls>
                    <PanelBody title={__('Display Settings', 'document-icon-checker')} initialOpen={true}>
                        <TextControl
                            label={__('Title', 'document-icon-checker')}
                            value={title}
                            onChange={(value) => setAttributes({ title: value })}
                            help={__('The main heading displayed above the uploader', 'document-icon-checker')}
                        />
                        <TextareaControl
                            label={__('Description', 'document-icon-checker')}
                            value={description}
                            onChange={(value) => setAttributes({ description: value })}
                            help={__('The description text shown below the title', 'document-icon-checker')}
                        />
                        <TextControl
                            label={__('Button Text', 'document-icon-checker')}
                            value={buttonText}
                            onChange={(value) => setAttributes({ buttonText: value })}
                            help={__('The text shown on the upload button', 'document-icon-checker')}
                        />
                    </PanelBody>

                    <PanelBody title={__('Document Checker Settings', 'document-icon-checker')} initialOpen={false}>
                        <SelectControl
                            multiple
                            label={__('Select Tables', 'document-icon-checker')}
                            value={tables}
                            options={availableTables}
                            onChange={(selected) => setAttributes({ tables: selected })}
                            help={__('Choose which tables to check documents against', 'document-icon-checker')}
                        />
                        
                        <RangeControl
                            label={__('File Size Limit (MB)', 'document-icon-checker')}
                            value={fileSizeLimit}
                            onChange={(value) => setAttributes({ fileSizeLimit: value })}
                            min={1}
                            max={50}
                            help={__('Maximum allowed file size in megabytes', 'document-icon-checker')}
                        />
                        
                        <ToggleControl
                            label={__('Enable Email Notifications', 'document-icon-checker')}
                            checked={enableEmail}
                            onChange={(value) => setAttributes({ enableEmail: value })}
                            help={__('Send email notifications when documents are uploaded', 'document-icon-checker')}
                        />
                        
                        {enableEmail && (
                            <TextControl
                                label={__('Notification Email', 'document-icon-checker')}
                                value={emailAddress}
                                onChange={(value) => setAttributes({ emailAddress: value })}
                                type="email"
                                help={__('Email address to receive notifications', 'document-icon-checker')}
                            />
                        )}
                    </PanelBody>
                </InspectorControls>

                <div className="document-checker-block-preview">
                    <div className="document-checker-header">
                        <h3>{title}</h3>
                        <p>{description}</p>
                    </div>
                    <div className="document-checker-content">
                        <div className="document-checker-settings">
                            <p><strong>{__('Selected Tables:', 'document-icon-checker')}</strong> {tables.length ? tables.length : __('None', 'document-icon-checker')}</p>
                            <p><strong>{__('Max File Size:', 'document-icon-checker')}</strong> {fileSizeLimit}MB</p>
                            <p><strong>{__('Email Notifications:', 'document-icon-checker')}</strong> {enableEmail ? __('Enabled', 'document-icon-checker') : __('Disabled', 'document-icon-checker')}</p>
                            {enableEmail && emailAddress && (
                                <p><strong>{__('Notification Email:', 'document-icon-checker')}</strong> {emailAddress}</p>
                            )}
                            <p><strong>{__('Button Text:', 'document-icon-checker')}</strong> {buttonText}</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    },

    save: () => null // Dynamic block, rendered by PHP
});