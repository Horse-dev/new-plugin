import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, TextControl, ToggleControl, RangeControl, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

registerBlockType('document-checker/uploader', {
    edit: ({ attributes, setAttributes }) => {
        const { tables, fileSizeLimit, enableEmail, emailAddress } = attributes;
        const [availableTables, setAvailableTables] = useState([]);
        const blockProps = useBlockProps();

        useEffect(() => {
            apiFetch({ path: '/wp/v2/dic-tables' })
                .then(response => {
                    setAvailableTables(response.map(table => ({
                        label: table.name,
                        value: table.id
                    })));
                })
                .catch(error => {
                    console.error('Error loading tables:', error);
                });
        }, []);

        return (
            <div {...blockProps}>
                <InspectorControls>
                    <PanelBody title={__('Document Checker Settings', 'document-icon-checker')} initialOpen={true}>
                        <SelectControl
                            multiple
                            label={__('Select Tables', 'document-icon-checker')}
                            value={tables}
                            options={availableTables}
                            onChange={(selected) => setAttributes({ tables: selected })}
                            help={__('Choose which tables to check documents against', 'document-icon-checker')}
                        />
                        
                        <RangeControl
                            label={__('File Size Limit (MB)', 'document-icon-checker')}
                            value={fileSizeLimit}
                            onChange={(value) => setAttributes({ fileSizeLimit: value })}
                            min={1}
                            max={50}
                            help={__('Maximum allowed file size in megabytes', 'document-icon-checker')}
                        />
                        
                        <ToggleControl
                            label={__('Enable Email Notifications', 'document-icon-checker')}
                            checked={enableEmail}
                            onChange={(value) => setAttributes({ enableEmail: value })}
                            help={__('Send email notifications when documents are uploaded', 'document-icon-checker')}
                        />
                        
                        {enableEmail && (
                            <TextControl
                                label={__('Notification Email', 'document-icon-checker')}
                                value={emailAddress}
                                onChange={(value) => setAttributes({ emailAddress: value })}
                                type="email"
                                help={__('Email address to receive notifications', 'document-icon-checker')}
                            />
                        )}
                    </PanelBody>
                </InspectorControls>

                <div className="document-checker-block-preview">
                    <div className="document-checker-icon">
                        <span className="dashicons dashicons-media-document"></span>
                    </div>
                    <div className="document-checker-content">
                        <h3>{__('Document Checker', 'document-icon-checker')}</h3>
                        <div className="document-checker-settings">
                            <p><strong>{__('Selected Tables:', 'document-icon-checker')}</strong> {tables.length ? tables.length : __('None', 'document-icon-checker')}</p>
                            <p><strong>{__('Max File Size:', 'document-icon-checker')}</strong> {fileSizeLimit}MB</p>
                            <p><strong>{__('Email Notifications:', 'document-icon-checker')}</strong> {enableEmail ? __('Enabled', 'document-icon-checker') : __('Disabled', 'document-icon-checker')}</p>
                            {enableEmail && emailAddress && (
                                <p><strong>{__('Notification Email:', 'document-icon-checker')}</strong> {emailAddress}</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        );
    },

    save: () => null // Dynamic block, rendered by PHP
});