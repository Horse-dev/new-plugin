import { registerBlockType } from '@wordpress/blocks';
import { Fragment } from '@wordpress/element';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl, ToggleControl, RangeControl, Placeholder } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';

registerBlockType('ai-document-checker/uploader', {
    apiVersion: 2,
    title: __('AI Document Checker', 'document-icon-checker'),
    description: __('Add a document upload and analysis field', 'document-icon-checker'),
    category: 'ai-tools',
    icon: 'media-document',
    supports: {
        html: false,
        multiple: false
    },
    attributes: {
        tables: {
            type: 'array',
            default: []
        },
        fileSizeLimit: {
            type: 'number',
            default: 10
        },
        enableEmail: {
            type: 'boolean',
            default: false
        },
        emailAddress: {
            type: 'string',
            default: ''
        }
    },

    edit: function Edit({ attributes, setAttributes }) {
        const { tables, fileSizeLimit, enableEmail, emailAddress } = attributes;
        const blockProps = useBlockProps();

        // Load available tables
        const loadTables = async () => {
            try {
                const response = await apiFetch({ path: '/wp/v2/dic-tables' });
                if (!tables.length) {
                    setAttributes({ tables: response.map(table => table.id) });
                }
            } catch (error) {
                console.error('Error loading tables:', error);
            }
        };

        React.useEffect(() => {
            loadTables();
        }, []);

        return (
            <Fragment>
                <InspectorControls>
                    <PanelBody title={__('Upload Settings', 'document-icon-checker')} initialOpen={true}>
                        <RangeControl
                            label={__('File Size Limit (MB)', 'document-icon-checker')}
                            value={fileSizeLimit}
                            onChange={(value) => setAttributes({ fileSizeLimit: value })}
                            min={1}
                            max={50}
                        />
                        <ToggleControl
                            label={__('Enable Email Notification', 'document-icon-checker')}
                            checked={enableEmail}
                            onChange={(value) => setAttributes({ enableEmail: value })}
                        />
                        {enableEmail && (
                            <TextControl
                                label={__('Email Address', 'document-icon-checker')}
                                value={emailAddress}
                                onChange={(value) => setAttributes({ emailAddress: value })}
                                type="email"
                            />
                        )}
                    </PanelBody>
                </InspectorControls>

                <div {...blockProps}>
                    <Placeholder
                        icon="media-document"
                        label={__('AI Document Checker', 'document-icon-checker')}
                        instructions={__('Document upload and analysis field', 'document-icon-checker')}
                    >
                        <div className="components-placeholder__fieldset">
                            <p>{__('Configuration:', 'document-icon-checker')}</p>
                            <ul>
                                <li>{__('Maximum file size:', 'document-icon-checker')} {fileSizeLimit}MB</li>
                                <li>
                                    {__('Email notification:', 'document-icon-checker')} 
                                    {enableEmail ? __('Enabled', 'document-icon-checker') : __('Disabled', 'document-icon-checker')}
                                </li>
                                {enableEmail && emailAddress && (
                                    <li>{__('Notification email:', 'document-icon-checker')} {emailAddress}</li>
                                )}
                            </ul>
                        </div>
                    </Placeholder>
                </div>
            </Fragment>
        );
    },

    save: function Save() {
        return null; // Dynamic block, rendered by PHP
    }
});