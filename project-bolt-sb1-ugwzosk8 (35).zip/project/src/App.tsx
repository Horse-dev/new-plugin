import React, { useState } from 'react';
import AdminPanel from './components/AdminPanel';
import FrontendUploader from './components/FrontendUploader';
import { FileUp as FileUpload, Upload, Settings, Table } from 'lucide-react';

// Mock data for demo
const mockTables = [
  { id: 1, name: 'Company Documents', type: 'documents', created_at: '2023-10-15T12:00:00Z' },
  { id: 2, name: 'Brand Assets', type: 'icons', created_at: '2023-10-16T14:30:00Z' },
  { id: 3, name: 'Legal Forms', type: 'documents', created_at: '2023-10-17T09:15:00Z' }
];

const mockEntries = {
  1: [
    { id: 1, title: 'Employee Handbook', keywords: 'policy,rules,conduct,guidelines', file_url: 'https://example.com/handbook.pdf' },
    { id: 2, title: 'NDA Template', keywords: 'confidential,agreement,disclosure,secret', file_url: 'https://example.com/nda.pdf' }
  ],
  2: [
    { id: 3, title: 'Company Logo', keywords: 'logo,brand,identity', file_url: 'https://example.com/logo.png' },
    { id: 4, title: 'Approval Stamp', keywords: 'approved,stamp,official', file_url: 'https://example.com/stamp.png' }
  ],
  3: [
    { id: 5, title: 'Contract Template', keywords: 'legal,agreement,terms,conditions', file_url: 'https://example.com/contract.pdf' }
  ]
};

function App() {
  const [activeTab, setActiveTab] = useState<'admin' | 'frontend' | 'settings'>('admin');
  const [selectedTable, setSelectedTable] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <FileUpload className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">AI Document Checker</h1>
          </div>
          <div className="text-sm text-gray-500">WordPress Plugin Demo</div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="flex border-b">
            <button
              className={`px-6 py-3 font-medium flex items-center ${
                activeTab === 'admin' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
              onClick={() => setActiveTab('admin')}
            >
              <Table className="h-5 w-5 mr-2" />
              Admin Panel
            </button>
            <button
              className={`px-6 py-3 font-medium flex items-center ${
                activeTab === 'frontend' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
              onClick={() => setActiveTab('frontend')}
            >
              <Upload className="h-5 w-5 mr-2" />
              Frontend Demo
            </button>
            <button
              className={`px-6 py-3 font-medium flex items-center ${
                activeTab === 'settings' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
              onClick={() => setActiveTab('settings')}
            >
              <Settings className="h-5 w-5 mr-2" />
              Settings
            </button>
          </div>

          <div className="p-6">
            {activeTab === 'admin' && (
              <AdminPanel 
                tables={mockTables} 
                entries={mockEntries} 
                selectedTable={selectedTable}
                setSelectedTable={setSelectedTable}
              />
            )}
            {activeTab === 'frontend' && (
              <FrontendUploader tables={mockTables} />
            )}
            {activeTab === 'settings' && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-800">Plugin Settings</h2>
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        File Size Limit (MB)
                      </label>
                      <input 
                        type="range" 
                        min="1" 
                        max="50" 
                        defaultValue="10"
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>1 MB</span>
                        <span>10 MB</span>
                        <span>50 MB</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center mt-4">
                      <input
                        id="email-notification"
                        type="checkbox"
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="email-notification" className="ml-2 block text-sm text-gray-700">
                        Enable email notifications for file uploads
                      </label>
                    </div>
                    
                    <div className="mt-4">
                      <label htmlFor="notification-email" className="block text-sm font-medium text-gray-700 mb-1">
                        Notification Email
                      </label>
                      <input
                        type="email"
                        id="notification-email"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        placeholder="admin@example.com"
                      />
                    </div>
                    
                    <div className="pt-5">
                      <button
                        type="button"
                        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        Save Settings
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <footer className="bg-white mt-12 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            AI Document Checker Plugin Demo © 2023 - Horse Dev Team
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;