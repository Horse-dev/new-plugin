import React, { useState, useRef } from 'react';
import { Upload, CheckCircle, XCircle, RefreshCw } from 'lucide-react';

interface Table {
  id: number;
  name: string;
  type: string;
  created_at: string;
}

interface FrontendUploaderProps {
  tables: Table[];
}

interface MatchResult {
  table: string;
  entry: string;
  keyword: string;
}

const FrontendUploader: React.FC<FrontendUploaderProps> = ({ tables }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'analyzing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Mock file upload and analysis
  const handleFileUpload = (file: File) => {
    // Check file type
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/svg+xml'
    ];
    
    if (!allowedTypes.includes(file.type)) {
      setErrorMessage('Invalid file type. Please upload PDF, DOC, DOCX, or image files.');
      setUploadStatus('error');
      return;
    }
    
    // Check file size (10MB limit for demo)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      setErrorMessage('File size exceeds the limit of 10MB.');
      setUploadStatus('error');
      return;
    }
    
    // Start upload simulation
    setIsUploading(true);
    setUploadStatus('uploading');
    setUploadProgress(0);
    
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const newProgress = prev + Math.random() * 10;
        if (newProgress >= 100) {
          clearInterval(interval);
          setUploadStatus('analyzing');
          
          // Simulate analysis delay
          setTimeout(() => {
            simulateAnalysis(file);
          }, 1500);
          
          return 100;
        }
        return newProgress;
      });
    }, 200);
  };
  
  // Simulate file analysis
  const simulateAnalysis = (file: File) => {
    // For demo purposes, we'll randomly decide if there's a match
    const hasMatch = Math.random() > 0.5;
    
    if (hasMatch) {
      // Generate random matches
      const mockMatches: MatchResult[] = [];
      const numMatches = Math.floor(Math.random() * 3) + 1; // 1-3 matches
      
      for (let i = 0; i < numMatches; i++) {
        const randomTable = tables[Math.floor(Math.random() * tables.length)];
        const keywords = ['confidential', 'agreement', 'policy', 'logo', 'stamp', 'signature', 'contract'];
        const randomKeyword = keywords[Math.floor(Math.random() * keywords.length)];
        
        mockMatches.push({
          table: randomTable.name,
          entry: `Sample Entry ${i + 1}`,
          keyword: randomKeyword
        });
      }
      
      setMatches(mockMatches);
      setUploadStatus('success');
    } else {
      setMatches([]);
      setUploadStatus('success');
    }
    
    setIsUploading(false);
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  };
  
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileUpload(e.target.files[0]);
    }
  };
  
  const handleReset = () => {
    setUploadStatus('idle');
    setUploadProgress(0);
    setErrorMessage('');
    setMatches([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">AI Document Checker</h2>
      
      {uploadStatus === 'idle' && (
        <div 
          className={`border-2 ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-dashed border-gray-300 bg-gray-50'} rounded-lg p-8 text-center cursor-pointer transition-all duration-200`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="flex flex-col items-center">
            <Upload className="h-12 w-12 text-gray-400 mb-3" />
            <p className="text-lg font-semibold text-gray-700 mb-2">
              Drag & drop files here or click to upload
            </p>
            <p className="text-sm text-gray-500">
              Allowed file types: PDF, DOC, DOCX, Images | Max size: 10MB
            </p>
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileInputChange}
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif,.svg"
            />
          </div>
        </div>
      )}
      
      {(uploadStatus === 'uploading' || uploadStatus === 'analyzing') && (
        <div className="border border-gray-200 rounded-lg p-8 bg-white">
          <div className="flex flex-col items-center">
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
              <div 
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" 
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="text-gray-700">
              {uploadStatus === 'uploading' 
                ? `Uploading... ${Math.round(uploadProgress)}%` 
                : 'Analyzing file...'}
            </p>
            {uploadStatus === 'analyzing' && (
              <RefreshCw className="h-5 w-5 text-blue-500 animate-spin mt-2" />
            )}
          </div>
        </div>
      )}
      
      {uploadStatus === 'success' && (
        <div className="border border-gray-200 rounded-lg p-8 bg-white">
          <div className="flex flex-col items-center">
            {matches.length > 0 ? (
              <>
                <CheckCircle className="h-12 w-12 text-green-500 mb-3" />
                <p className="text-lg font-semibold text-gray-700 mb-4">
                  Your document matches!
                </p>
                <div className="w-full bg-gray-50 rounded-lg p-4 mb-4 text-left">
                  {matches.map((match, index) => (
                    <div key={index} className="mb-3 pb-3 border-b border-gray-200 last:border-0 last:mb-0 last:pb-0">
                      <div className="font-medium text-blue-600">{match.table}</div>
                      <div>Entry: <span className="font-medium">{match.entry}</span></div>
                      <div>
                        Matched keyword: <span className="bg-yellow-200 px-1 rounded">{match.keyword}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <>
                <XCircle className="h-12 w-12 text-red-500 mb-3" />
                <p className="text-lg font-semibold text-gray-700 mb-4">
                  No match found.
                </p>
              </>
            )}
            <button
              className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              onClick={handleReset}
            >
              Upload Another File
            </button>
          </div>
        </div>
      )}
      
      {uploadStatus === 'error' && (
        <div className="border border-gray-200 rounded-lg p-8 bg-white">
          <div className="flex flex-col items-center">
            <XCircle className="h-12 w-12 text-red-500 mb-3" />
            <p className="text-lg font-semibold text-gray-700 mb-4">
              {errorMessage}
            </p>
            <button
              className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              onClick={handleReset}
            >
              Try Again
            </button>
          </div>
        </div>
      )}
      
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-800 mb-2">About this demo</h3>
        <p className="text-sm text-blue-700">
          This is a demonstration of the AI Document Checker WordPress plugin. In a real implementation, 
          the plugin would analyze uploaded files using AI to extract text and identify visual elements, 
          then compare them against your database of documents, icons, stamps, and shapes.
        </p>
      </div>
    </div>
  );
};

export default FrontendUploader;