import React, { useState } from 'react';
import { PlusCircle, Edit, Trash2, FileText, Image } from 'lucide-react';

interface Table {
  id: number;
  name: string;
  type: string;
  created_at: string;
}

interface Entry {
  id: number;
  title: string;
  keywords: string;
  file_url: string;
}

interface AdminPanelProps {
  tables: Table[];
  entries: Record<number, Entry[]>;
  selectedTable: number | null;
  setSelectedTable: (id: number | null) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  tables, 
  entries, 
  selectedTable, 
  setSelectedTable 
}) => {
  const [activeTab, setActiveTab] = useState<'tables' | 'entries'>('tables');
  const [showAddTableModal, setShowAddTableModal] = useState(false);
  const [showAddEntryModal, setShowAddEntryModal] = useState(false);
  const [showEditTableModal, setShowEditTableModal] = useState(false);
  const [editingTable, setEditingTable] = useState<Table | null>(null);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  const handleEditTable = (table: Table) => {
    setEditingTable(table);
    setShowEditTableModal(true);
  };

  const handleDeleteTable = (tableId: number) => {
    if (confirm('Are you sure you want to delete this table? This action cannot be undone.')) {
      // In a real implementation, this would make an AJAX call to delete the table
      console.log('Deleting table:', tableId);
    }
  };

  const handleDeleteEntry = (entryId: number) => {
    if (confirm('Are you sure you want to delete this entry? This action cannot be undone.')) {
      // In a real implementation, this would make an AJAX call to delete the entry
      console.log('Deleting entry:', entryId);
    }
  };

  return (
    <div>
      <div className="flex border-b mb-6">
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'tables' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'
          }`}
          onClick={() => setActiveTab('tables')}
        >
          Tables
        </button>
        <button
          className={`px-4 py-2 font-medium ${
            activeTab === 'entries' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'
          }`}
          onClick={() => setActiveTab('entries')}
        >
          Entries
        </button>
      </div>

      {activeTab === 'tables' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Tables</h2>
            <button
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              onClick={() => setShowAddTableModal(true)}
            >
              <PlusCircle className="h-4 w-4 mr-1" />
              Add New Table
            </button>
          </div>

          <div className="bg-white shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {tables.map((table) => (
                  <tr key={table.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{table.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {table.type === 'documents' ? (
                          <FileText className="h-4 w-4 text-blue-500 mr-1" />
                        ) : (
                          <Image className="h-4 w-4 text-green-500 mr-1" />
                        )}
                        <span className="text-sm text-gray-500">
                          {table.type === 'documents' ? 'Documents Table' : 'Icons, Stamps & Shapes Table'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(table.created_at)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        className="text-blue-600 hover:text-blue-900 mr-3"
                        onClick={() => handleEditTable(table)}
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        className="text-red-600 hover:text-red-900"
                        onClick={() => handleDeleteTable(table.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'entries' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Entries</h2>
            <div className="flex items-center space-x-4">
              <div>
                <label htmlFor="table-select" className="sr-only">
                  Select Table
                </label>
                <select
                  id="table-select"
                  className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  value={selectedTable || ''}
                  onChange={(e) => setSelectedTable(e.target.value ? Number(e.target.value) : null)}
                >
                  <option value="">-- Select a table --</option>
                  {tables.map((table) => (
                    <option key={table.id} value={table.id}>
                      {table.name}
                    </option>
                  ))}
                </select>
              </div>
              <button
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => setShowAddEntryModal(true)}
                disabled={!selectedTable}
              >
                <PlusCircle className="h-4 w-4 mr-1" />
                Add New Entry
              </button>
            </div>
          </div>

          {!selectedTable ? (
            <div className="bg-white p-6 text-center text-gray-500 italic rounded-lg border border-gray-200">
              Please select a table to view entries.
            </div>
          ) : entries[selectedTable]?.length === 0 ? (
            <div className="bg-white p-6 text-center text-gray-500 italic rounded-lg border border-gray-200">
              No entries found in this table. Click "Add New Entry" to create one.
            </div>
          ) : (
            <div className="bg-white shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Title
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Keywords
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      File
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {entries[selectedTable]?.map((entry) => (
                    <tr key={entry.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{entry.title}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-500">
                          {entry.keywords.split(',').map((keyword, index) => (
                            <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mr-1 mb-1">
                              {keyword.trim()}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {entry.file_url ? (
                          <a href={entry.file_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-900">
                            View File
                          </a>
                        ) : (
                          'No file'
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          className="text-blue-600 hover:text-blue-900 mr-3"
                          onClick={() => console.log('Edit entry:', entry.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          className="text-red-600 hover:text-red-900"
                          onClick={() => handleDeleteEntry(entry.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Add Table Modal */}
      {showAddTableModal && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">Add New Table</h3>
            </div>
            <div className="px-6 py-4">
              <div className="mb-4">
                <label htmlFor="table-name" className="block text-sm font-medium text-gray-700 mb-1">
                  Table Name:
                </label>
                <input
                  type="text"
                  id="table-name"
                  className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  placeholder="Enter table name"
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Table Type:
                </label>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input
                      id="documents-type"
                      name="table-type"
                      type="radio"
                      defaultChecked
                      className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300"
                    />
                    <label htmlFor="documents-type" className="ml-3 block text-sm font-medium text-gray-700">
                      Documents Table (keywords & values)
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      id="icons-type"
                      name="table-type"
                      type="radio"
                      className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300"
                    />
                    <label htmlFor="icons-type" className="ml-3 block text-sm font-medium text-gray-700">
                      Icons, Stamps & Shapes Table
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 text-right rounded-b-lg">
              <button
                type="button"
                className="inline-flex justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 mr-3"
                onClick={() => setShowAddTableModal(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => {
                  console.log('Create table');
                  setShowAddTableModal(false);
                }}
              >
                Create Table
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Table Modal */}
      {showEditTableModal && editingTable && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">Rename Table</h3>
            </div>
            <div className="px-6 py-4">
              <div className="mb-4">
                <label htmlFor="edit-table-name" className="block text-sm font-medium text-gray-700 mb-1">
                  Table Name:
                </label>
                <input
                  type="text"
                  id="edit-table-name"
                  className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  defaultValue={editingTable.name}
                />
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 text-right rounded-b-lg">
              <button
                type="button"
                className="inline-flex justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 mr-3"
                onClick={() => setShowEditTableModal(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => {
                  console.log('Rename table:', editingTable.id);
                  setShowEditTableModal(false);
                }}
              >
                Rename Table
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Entry Modal */}
      {showAddEntryModal && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">Add New Entry</h3>
            </div>
            <div className="px-6 py-4">
              <div className="mb-4">
                <label htmlFor="entry-title" className="block text-sm font-medium text-gray-700 mb-1">
                  Title:
                </label>
                <input
                  type="text"
                  id="entry-title"
                  className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  placeholder="Enter entry title"
                />
              </div>
              <div className="mb-4">
                <label htmlFor="entry-keywords" className="block text-sm font-medium text-gray-700 mb-1">
                  Keywords (comma-separated):
                </label>
                <textarea
                  id="entry-keywords"
                  rows={4}
                  className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  placeholder="keyword1, keyword2, keyword3"
                ></textarea>
              </div>
              <div className="mb-4">
                <label htmlFor="entry-file" className="block text-sm font-medium text-gray-700 mb-1">
                  File (optional):
                </label>
                <input
                  type="file"
                  id="entry-file"
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Allowed file types: PDF, DOC, DOCX, JPG, PNG, GIF, SVG
                </p>
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 text-right rounded-b-lg">
              <button
                type="button"
                className="inline-flex justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 mr-3"
                onClick={() => setShowAddEntryModal(false)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => {
                  console.log('Add entry to table:', selectedTable);
                  setShowAddEntryModal(false);
                }}
              >
                Add Entry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;