<?php
// Silence is golden.
// This file is required for WordPress to recognize the plugin.

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

// Include the main plugin file
require_once plugin_dir_path(__FILE__) . 'ai-doc-checker.php';